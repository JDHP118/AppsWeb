--Tabla de usuarios
Create table Usuario(
	id int  NOT NULL PRIMARY KEY AUTO_INCREMENT, PrimerNombre varchar(20), Apellido varchar(20), 
	email varchar(50), usuario varchar(20), contrasena varchar(20), calle varchar(20), numero int, 
	ciudad varchar(20), estado varchar(20), telefonos varchar(20));
	
--Tabla de boletos
Create table Boletos(
	id int  NOT NULL PRIMARY KEY, idProducto int , Precio varchar(20), idUsuarioB int, 
	nombre varchar(20),FOREIGN KEY (idUsuarioB) references usuario(id));
	
--Tabla de vendedores
Create table Vendedores(
	id int NOT NULL PRIMARY KEY AUTO_INCREMENT, PrimerNombre varchar(20), Apellido varchar(20), 
	email varchar(50), usuario varchar(20), contrasena varchar(20), calle varchar(20), numero int, 
	ciudad varchar(20), estado varchar(20), telefonos varchar(20));

--Tabla de recibe
Create table recibe(
	idUsuario int , idVendedor int, reg_fun varchar(20), primary key(idUsuario), idUsuarioR int,
	idVendedorR int, FOREIGN KEY (idUsuarioR) references usuario(id), FOREIGN KEY (idVendedorR) references vendedores(id));

--Tabla de productos
Create table Productos(
	id int NOT NULL PRIMARY KEY AUTO_INCREMENT, nombre varchar(20), categoria varchar(20), precio int, 
	idVendedorP int,idBoletosP int, FOREIGN KEY (idBoletosP) references Boletos(id), 
	FOREIGN KEY (idVendedorP) references vendedores(id));
	
